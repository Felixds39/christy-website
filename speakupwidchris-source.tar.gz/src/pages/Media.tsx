import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Play, Image as ImageIcon } from "lucide-react";

interface MediaItem {
  id: string;
  title: string;
  description: string | null;
  type: string;
  url: string;
  thumbnail_url: string | null;
  category: string | null;
}

const categories = ["All", "Talks", "Workshops", "Lectures", "Events", "Interviews"];

const Media = () => {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");

  useEffect(() => {
    supabase
      .from("media_items_public")
      .select("*")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setItems(data || []);
        setLoading(false);
      });
  }, []);

  const filtered = activeCategory === "All" ? items : items.filter((i) => i.category === activeCategory);

  const getEmbedUrl = (item: MediaItem) => {
    if (item.type === "youtube") {
      const id = item.url.match(/(?:youtu\.be\/|v=)([\w-]+)/)?.[1];
      if (id && /^[a-zA-Z0-9_-]{11}$/.test(id)) {
        return `https://www.youtube.com/embed/${id}`;
      }
      return null;
    }
    if (item.type === "vimeo") {
      const id = item.url.match(/vimeo\.com\/(\d+)/)?.[1];
      if (id && /^\d{1,20}$/.test(id)) {
        return `https://player.vimeo.com/video/${id}`;
      }
      return null;
    }
    return null;
  };

  return (
    <Layout>
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h1 className="font-display text-4xl font-bold text-center"><span className="text-gradient">Media Gallery</span></h1>
          <p className="mx-auto mt-4 max-w-xl text-center text-muted-foreground">
            Watch talks, workshops, lectures, and interviews.
          </p>

          <Tabs value={activeCategory} onValueChange={setActiveCategory} className="mt-10">
            <TabsList className="mx-auto flex w-fit flex-wrap">
              {categories.map((c) => (
                <TabsTrigger key={c} value={c}>{c}</TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value={activeCategory} className="mt-8">
              {loading ? (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {[1, 2, 3].map((i) => <div key={i} className="h-56 animate-pulse rounded-xl bg-muted" />)}
                </div>
              ) : filtered.length === 0 ? (
                <p className="text-center text-muted-foreground py-12">No media items yet.</p>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filtered.map((item) => {
                    const embedUrl = getEmbedUrl(item);
                    return (
                      <Card key={item.id} className="overflow-hidden">
                        {embedUrl ? (
                          <div className="aspect-video">
                            <iframe
                              src={embedUrl}
                              title={item.title}
                              className="h-full w-full"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            />
                          </div>
                        ) : item.type === "video" ? (
                          <div className="aspect-video">
                            <video src={item.url} controls className="h-full w-full object-cover" />
                          </div>
                        ) : (
                          <div className="aspect-video overflow-hidden">
                            <img src={item.url} alt={item.title} className="h-full w-full object-cover" />
                          </div>
                        )}
                        <CardContent className="p-4">
                          <h3 className="font-semibold">{item.title}</h3>
                          {item.description && <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{item.description}</p>}
                          {item.category && <span className="mt-2 inline-block rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">{item.category}</span>}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </Layout>
  );
};

export default Media;
