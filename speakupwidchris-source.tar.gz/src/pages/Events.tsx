import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar, MapPin, Clock } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface Event {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  start_time: string;
  end_time: string | null;
  registration_deadline: string | null;
}

const Events = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("events")
      .select("*")
      .eq("is_published", true)
      .order("start_time", { ascending: true })
      .then(({ data }) => {
        setEvents(data || []);
        setLoading(false);
      });
  }, []);

  const handleRegister = async (eventId: string, formData: FormData) => {
    const name = formData.get("name") as string;
    const email = formData.get("email") as string;
    const phone = formData.get("phone") as string;
    const message = formData.get("message") as string;

    const { error } = await supabase.from("event_registrations").insert({
      event_id: eventId,
      name,
      email,
      phone: phone || null,
      message: message || null,
    });

    if (error) {
      toast.error("Registration failed. Please try again.");
    } else {
      toast.success("Successfully registered!");
    }
  };

  return (
    <Layout>
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h1 className="font-display text-4xl font-bold text-center"><span className="text-gradient">Events</span></h1>
          <p className="mx-auto mt-4 max-w-xl text-center text-muted-foreground">
            Upcoming workshops, lectures, and speaking events.
          </p>

          {loading ? (
            <div className="mt-12 space-y-6">
              {[1, 2].map((i) => <div key={i} className="h-40 animate-pulse rounded-xl bg-muted" />)}
            </div>
          ) : events.length === 0 ? (
            <p className="mt-12 text-center text-muted-foreground">No upcoming events. Stay tuned!</p>
          ) : (
            <div className="mt-12 space-y-6">
              {events.map((event) => (
                <Card key={event.id}>
                  <CardHeader>
                    <CardTitle className="font-display text-2xl">{event.title}</CardTitle>
                    <CardDescription className="flex flex-wrap gap-4 mt-2">
                      <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{new Date(event.start_time).toLocaleDateString()}</span>
                      <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{new Date(event.start_time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                      {event.location && <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{event.location}</span>}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex items-start justify-between gap-4">
                    <p className="text-muted-foreground flex-1">{event.description}</p>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="bg-brand-gradient text-primary-foreground shrink-0">Register</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Register for {event.title}</DialogTitle>
                        </DialogHeader>
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            handleRegister(event.id, new FormData(e.currentTarget));
                          }}
                          className="space-y-4"
                        >
                          <div><Label htmlFor="name">Name *</Label><Input id="name" name="name" required /></div>
                          <div><Label htmlFor="email">Email *</Label><Input id="email" name="email" type="email" required /></div>
                          <div><Label htmlFor="phone">Phone</Label><Input id="phone" name="phone" /></div>
                          <div><Label htmlFor="message">Message</Label><Textarea id="message" name="message" /></div>
                          <Button type="submit" className="w-full bg-brand-gradient text-primary-foreground">Submit Registration</Button>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Events;
