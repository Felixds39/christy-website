import { useState } from "react";
import Layout from "@/components/Layout";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Mail, MessageSquare, Newspaper } from "lucide-react";

const Contact = () => {
  const [contactLoading, setContactLoading] = useState(false);
  const [feedbackLoading, setFeedbackLoading] = useState(false);
  const [newsletterLoading, setNewsletterLoading] = useState(false);

  const submitForm = async (type: string, data: Record<string, string>, setLoading: (v: boolean) => void) => {
    setLoading(true);
    const { error } = await supabase.from("form_submissions").insert({
      form_type: type,
      data,
      email: data.email || null,
    });
    setLoading(false);
    if (error) toast.error("Submission failed. Please try again.");
    else toast.success("Thank you for your submission!");
  };

  return (
    <Layout>
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h1 className="font-display text-4xl font-bold text-center"><span className="text-gradient">Get in Touch</span></h1>
          <p className="mx-auto mt-4 max-w-xl text-center text-muted-foreground">
            Have a question or want to collaborate? Reach out!
          </p>

          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {/* Contact Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5 text-primary" /> Contact</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const fd = new FormData(e.currentTarget);
                    submitForm("contact", {
                      name: fd.get("name") as string,
                      email: fd.get("email") as string,
                      message: fd.get("message") as string,
                    }, setContactLoading);
                    e.currentTarget.reset();
                  }}
                  className="space-y-4"
                >
                  <div><Label>Name</Label><Input name="name" required /></div>
                  <div><Label>Email</Label><Input name="email" type="email" required /></div>
                  <div><Label>Message</Label><Textarea name="message" required /></div>
                  <Button type="submit" className="w-full bg-brand-gradient text-primary-foreground" disabled={contactLoading}>
                    {contactLoading ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Feedback Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><MessageSquare className="h-5 w-5 text-primary" /> Feedback</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const fd = new FormData(e.currentTarget);
                    submitForm("feedback", {
                      name: fd.get("name") as string,
                      email: fd.get("email") as string,
                      feedback: fd.get("feedback") as string,
                      rating: fd.get("rating") as string,
                    }, setFeedbackLoading);
                    e.currentTarget.reset();
                  }}
                  className="space-y-4"
                >
                  <div><Label>Name</Label><Input name="name" required /></div>
                  <div><Label>Email</Label><Input name="email" type="email" required /></div>
                  <div><Label>Rating (1-5)</Label><Input name="rating" type="number" min="1" max="5" required /></div>
                  <div><Label>Feedback</Label><Textarea name="feedback" required /></div>
                  <Button type="submit" className="w-full bg-brand-gradient text-primary-foreground" disabled={feedbackLoading}>
                    {feedbackLoading ? "Sending..." : "Submit Feedback"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Newsletter */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Newspaper className="h-5 w-5 text-primary" /> Newsletter</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Subscribe for updates on new blog posts, events, and workshops.</p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const fd = new FormData(e.currentTarget);
                    submitForm("newsletter", {
                      email: fd.get("email") as string,
                      name: fd.get("name") as string,
                    }, setNewsletterLoading);
                    e.currentTarget.reset();
                  }}
                  className="space-y-4"
                >
                  <div><Label>Name</Label><Input name="name" required /></div>
                  <div><Label>Email</Label><Input name="email" type="email" required /></div>
                  <Button type="submit" className="w-full bg-brand-gradient text-primary-foreground" disabled={newsletterLoading}>
                    {newsletterLoading ? "Subscribing..." : "Subscribe"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;
