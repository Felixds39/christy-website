import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen, Users, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import profilePhoto from "@/assets/profile-photo.jpg";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const Index = () => (
  <Layout>
    {/* Hero */}
    <section className="relative overflow-hidden py-24 md:py-36">
      <div className="absolute inset-0 bg-brand-gradient opacity-5" />
      <div className="container relative mx-auto px-4 text-center">
        <motion.h1
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          className="font-display text-4xl font-bold leading-tight md:text-6xl"
        >
          <span className="text-gradient">Speak_Up</span> wid Chris
        </motion.h1>
        <motion.p
          initial="hidden"
          animate="visible"
          variants={{ ...fadeUp, visible: { ...fadeUp.visible, transition: { delay: 0.2, duration: 0.6 } } }}
          className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground"
        >
          Empowering Voices. Inspiring Change. A platform dedicated to strengthening
          confidence and inspiring meaningful communication.
        </motion.p>
        <motion.div
          initial="hidden"
          animate="visible"
          variants={{ ...fadeUp, visible: { ...fadeUp.visible, transition: { delay: 0.4, duration: 0.6 } } }}
          className="mt-8 flex flex-wrap justify-center gap-4"
        >
          <Link to="/blog">
            <Button size="lg" className="bg-brand-gradient text-primary-foreground hover:opacity-90">
              Read the Blog <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
          <Link to="/contact">
            <Button size="lg" variant="outline">Join the Community</Button>
          </Link>
        </motion.div>
      </div>
    </section>

    {/* Bio preview */}
    <section className="py-20">
      <div className="container mx-auto flex flex-col items-center gap-10 px-4 md:flex-row">
        <motion.img
          src={profilePhoto}
          alt="Dr. Gincy Susan George"
          className="h-64 w-64 rounded-full object-cover shadow-xl ring-4 ring-primary/20"
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        />
        <div className="max-w-xl text-center md:text-left">
          <h2 className="font-display text-3xl font-bold">Dr. Gincy Susan George</h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            An accomplished academic leader, educator, and mental health specialist with advanced
            expertise in Psychiatric Mental Health Nursing. Through Speak_Up wid Chris, she creates
            a platform where individuals can discover their voice, overcome fear, and communicate
            with authenticity and impact.
          </p>
          <Link to="/about">
            <Button variant="link" className="mt-4 p-0 text-primary">
              Learn more <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>

    {/* Features */}
    <section className="bg-muted/30 py-20">
      <div className="container mx-auto grid gap-8 px-4 md:grid-cols-3">
        {[
          { icon: BookOpen, title: "Blog & Insights", desc: "Articles on leadership, communication, and mental health.", link: "/blog" },
          { icon: Users, title: "Talks & Media", desc: "Watch inspiring talks, workshops, and interviews.", link: "/media" },
          { icon: Calendar, title: "Events", desc: "Join upcoming workshops, lectures, and speaking events.", link: "/events" },
        ].map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15, duration: 0.5 }}
          >
            <Link
              to={f.link}
              className="group block rounded-xl border bg-card p-8 shadow-sm transition-all hover:shadow-lg hover:-translate-y-1"
            >
              <f.icon className="h-10 w-10 text-primary" />
              <h3 className="mt-4 font-display text-xl font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  </Layout>
);

export default Index;
